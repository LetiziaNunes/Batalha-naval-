import java.io.File
const val MENU_PRINCIPAL = 100
const val MENU_DEFINIR_TABULEIRO = 101
const val MENU_DEFINIR_NAVIOS = 102
const val MENU_JOGAR = 103
const val MENU_LER_FICHEIRO = 104
const val MENU_GRAVAR_FICHEIRO = 105
const val SAIR = 106


fun tamanhoTabuleiroValido(numLinhas: Int, numColunas: Int): Boolean {
    return (numLinhas == 4) && (numColunas == 4) ||
            ((numLinhas == 5) && (numColunas == 5)) ||
            ((numLinhas == 7) && (numColunas == 7)) ||
            ((numLinhas == 8) && (numColunas == 8)) ||
            ((numLinhas == 10) && (numColunas == 10))
}

fun processaCoordenadas(coordenadas: String, numLinhas: Int, numColunas: Int): Pair<Int, Int>? {
    var coletor = ""
    //vai coletar cada elemento da string
    var count = 0
    val ultimaLetra = coordenadas[coordenadas.length - 1]
    //o último elemento tem que ser uma letra para que a coordenada seja válida
    //então vai buscar a última posição
    //coordenadas.lenght-1
    val teste = ultimaLetra.isLetter()
    //verifica se a última posição é letra

    if (!(teste)) {
        //se a última posição não for letra então a função vai retornar null
        return null
    }
    while (count < coordenadas.length - 1) {
        //enquanto o count for menor que o tamanho da letra -1
        //menos 1 para acessar à primeira posição "0"
        if (coordenadas[count] != ',') {
            //enquanto a coordenada for diferente de , ele vai coletar
            coletor += coordenadas[count]
        }
        count++
    }
    val letraParaColuna = ultimaLetra - 'A'
    //vai subrair o valorde A na tabela ascii no valor da última letra
    //fazemos isto para obter a posição da letra em relação ao A
    return if ((ultimaLetra.code <= numColunas + 64) && (coletor.toInt() <= numLinhas)) {
        //se o código da última letra for menor que o numero de colunas + 64
        //mais 64 pois se somarmos as colunas iria ultrapassar o velor real
        //a segunda condição verifica se o valor obido no coletor é menor que o número de linhas
        Pair(coletor.toInt(), letraParaColuna + 1)
        //neste caso é + 1 pois na função letra para coluna estavamos a falar de posições
        //agora estamos a falar dos valores reais, ex: agora o A seria o 1, e o B o 2
        //antes estava a respresentar como se o A fosse o 0 e o B o 1
    } else {
        null
    }
}

fun criaLegendaHorizontal(numColunas: Int): String {
    //esta função vai criar a primeira linha do tabuleiro
    var count = 0
    var coletor = ""
    //coleta tudo para depois imprimir
    while (count < numColunas) {
        coletor += (count + 65).toChar()
        //o coletor vai receber o count mais o código de A na tabela de ascii
        // para retornar a respetiva letra
        if (count != numColunas - 1) {
            //vai servir para adicionar o traço vertical, ou seja,
            //se o count for menor que o numero de colunas menos 1, no caso vai adicionar uma linha
            // até o último espaço
            coletor += " | "
        }
        count++
    }
    return (coletor).trim()
    //o trim serve para retirar os espaços em branco
}

fun criaTerreno(numLinhas: Int, numColunas: Int): String {

    var countColunas = 0
    var countLinha = 0
    var coletor1 = "| "
    var coletorLinha = ""


    while (countColunas < numColunas) {
        coletor1 += "~ | "
        countColunas++
    }

    while (countLinha < numLinhas) {
        coletorLinha += "$coletor1${countLinha + 1}\n"
        countLinha++
    }

    return "\n" + "| " + criaLegendaHorizontal(numColunas) + " |" + "\n" + coletorLinha
}

var numLinhas = -1
var numColunas = -1

var tabuleiroHumano: Array<Array<Char?>> = emptyArray()
var tabuleiroComputador: Array<Array<Char?>> = emptyArray()

var tabuleiroPalpitesDoHumano: Array<Array<Char?>> = emptyArray()
var tabuleiroPalpitesDoComputador: Array<Array<Char?>> = emptyArray()

fun calculaNumNavios(numLinhas: Int, numColunas: Int): Array<Int> {
    //calcula o número de navios que vai ser utilizado em cada mapa
    //dependendo da sua dimenão
    val numNavios = Array(4) { 0 }
    if(tamanhoTabuleiroValido(numLinhas,numColunas)){
        //se o tabuleiro for válido
        when(numLinhas){
            4->return arrayOf(2,0,0,0)
            5->return arrayOf(1,1,1,0)
            7->return arrayOf(2,1,1,1)
            8->return arrayOf(2,2,1,1)
            10->return arrayOf(3,2,1,1)
            //cada tabuleiro vai ter um x numero de navios diversos
        }
    }
    //se não acontecer a condição anterior,então vai retornar um empty
    return emptyArray()
}

fun criaTabuleiroVazio(numLinhas: Int, numColunas: Int): Array<Array<Char?>> {
    val tabuleiro = Array(numLinhas) { Array<Char?>(numColunas) { null } }
    //vai criar um array no caso vazio
    //vai ser um array com size numLinhas
    //e cada um dos espaços do array vai ser inicializado por um array size numColunas
    // preenchidos com null
    return tabuleiro
}

fun coordenadaContida(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int): Boolean {
    //estafunção vai verificar se a coordenada está contida
    //dependendo do tamanho do tabuleiro
    val dimensao = tabuleiro.size
    //a dimensão vai ser o size do tabuleiro
    //por exemplo, se o tabuleiro for 5x5, a dimensão será 5
    return (linha >= 1 && coluna >= 1) && (linha <= dimensao && coluna <= dimensao)
    //se a limha/coluna for maior que 1 retorna true, esta vai verificar se a linha
}

fun limparCoordenadasVazias(coordenadas: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {
    //vai limpar todas as coordenadas que sejam (0,0)
    var countCoordenadasVazias = 0
    for (coordenada in coordenadas) {
        if (coordenada.first == 0 && coordenada.second == 0) {
            //ele pega no primeiro membro da coordenada e no último e verifica se é igual a zero
            //se for igual a zero então vai pegar na coodenada e vai contar no count
            countCoordenadasVazias++
        }
    }
    val arrayFinal = Array<Pair<Int, Int>>(coordenadas.size - countCoordenadasVazias) { Pair(0, 0) }
    //inicia um array com size coordenadas(quantas coordenadas foram postas no início)-
    //e vai subtrair o count das coordenadas vazias
    //inicializa o array em (0,0)
    var countArrayFinal=0
    for (coordenada in coordenadas) {
        if (coordenada.first != 0 && coordenada.second != 0) {
            //como inicializamos o array em 0, vai subtituir com as coordenadas que não estão com 0
            arrayFinal[countArrayFinal]=coordenada
            countArrayFinal++
        }
    }
    return arrayFinal
}

fun juntarCoordenadas(coordenadas1: Array<Pair<Int, Int>>, coordenadas2: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {
    val coordenadaFinal= coordenadas1+coordenadas2
    return coordenadaFinal
    //pega em duas coordenadas e faz a soma de coordenadas
}

fun gerarCoordenadasNavio(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Array<Pair<Int, Int>> {
    val arrayFinal = Array<Pair<Int, Int>>(dimensao) { Pair(0, 0) }
    //cria um array que o size vai ser a dimensão do navio inicializa com (0,0)
    for (i in  0 until dimensao){
        when(orientacao){
            "E"->{
                if (coordenadaContida(tabuleiro,linha,coluna+i)) {
                    //se a coordenada estiver contida
                    //e vai utilizar o coluna +1, pois a orientação este é para a direita
                    arrayFinal[i]= Pair(linha, coluna + i)
                }else{
                    return emptyArray()
                }
            }
            "N"->{
                if (coordenadaContida(tabuleiro,linha-i,coluna)) {
                    //e vai utilizar o linha-1, pois a orientação norte é para cima
                    arrayFinal[i]= Pair(linha-i, coluna)
                }else{
                    return emptyArray()
                }
            }
            "S"->{
                if (coordenadaContida(tabuleiro,linha+i,coluna)) {
                    //e vai utilizar o linha+1, pois a orientação sul é para cima
                    arrayFinal[i]= Pair(linha+i, coluna)
                }else{
                    return emptyArray()
                }
            }
            "O"->{
                if (coordenadaContida(tabuleiro,linha,coluna-i)) {
                    //e vai utilizar o coluna -1, pois a orientação oeste é para a esquerda
                    arrayFinal[i]= Pair(linha, coluna-i)
                }else{
                    return emptyArray()
                }
            }
        }
    }
    return arrayFinal
}

fun estaValida(tabuleiro: Array<Array<Char?>>,coordenada:Pair<Int,Int>):Pair<Int,Int>{
    if (coordenadaContida(tabuleiro,coordenada.first,coordenada.second)){
        return coordenada
    }
    return Pair(0,0)
}

fun coordenadasResto(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int):Array<Pair<Int,Int>>{
    val coordenadasDoNavio=gerarCoordenadasNavio(tabuleiro,linha,coluna,orientacao,dimensao)
    if (coordenadasDoNavio.isEmpty()){
        return emptyArray()
    }
    var coordenadaResto =Array<Pair<Int, Int>>(2*dimensao) { Pair(0, 0) }
    val casasAdjacente1=Array<Pair<Int,Int>>(dimensao){Pair(0,0)}
    val casasAdjacente2=Array<Pair<Int,Int>>(dimensao){Pair(0,0)}
    var primeiraCasa=coordenadasDoNavio.first()

    if (orientacao == "N"|| orientacao == "O"){
        primeiraCasa=coordenadasDoNavio.last()
    }
    if (orientacao == "E"|| orientacao == "O"){
        val coordenadaAcima=Pair(primeiraCasa.first-1,primeiraCasa.second)
        val coordenadaAbaixo=Pair(primeiraCasa.first+1,primeiraCasa.second)
        var acima:Pair<Int, Int>
        var abaixo:Pair<Int, Int>

        for (i in 0 until dimensao){
            acima=estaValida(tabuleiro,Pair(coordenadaAcima.first,coordenadaAcima.second+i))
            abaixo=estaValida(tabuleiro,Pair(coordenadaAbaixo.first,coordenadaAbaixo.second+i))
            casasAdjacente1[i]=acima
            casasAdjacente2[i]=abaixo
        }
    }
    if (orientacao == "N"|| orientacao == "S"){
        val coordenadaEsquerda=Pair(primeiraCasa.first,primeiraCasa.second-1)
        val coordenadaDireita=Pair(primeiraCasa.first,primeiraCasa.second+1)
        var esquerda:Pair<Int, Int>
        var direita:Pair<Int, Int>

        for (i in 0 until dimensao){
            esquerda=estaValida(tabuleiro,Pair(coordenadaEsquerda.first+i,coordenadaEsquerda.second))
            direita=estaValida(tabuleiro,Pair(coordenadaDireita.first+i,coordenadaDireita.second))
            casasAdjacente1[i]=esquerda
            casasAdjacente2[i]=direita
        }
    }
    coordenadaResto=juntarCoordenadas(casasAdjacente1,casasAdjacente2)
    return limparCoordenadasVazias(coordenadaResto)
}

fun gerarCoordenadasFronteira(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Array<Pair<Int, Int>> {
    val coordenadasCanto = Array<Pair<Int, Int>>(4) { Pair(0, 0) }
    val coordenadaExtremos = Array<Pair<Int, Int>>(2) { Pair(0, 0) }
    val coordenadasResto =coordenadasResto(tabuleiro,linha,coluna,orientacao,dimensao)
    val coordenadasDoNavio=gerarCoordenadasNavio(tabuleiro,linha,coluna,orientacao,dimensao)
    if (coordenadasDoNavio.isEmpty()){
        return emptyArray()
    }
    val primeiraCasa=coordenadasDoNavio.first()
    val ultimaCasa=coordenadasDoNavio.last()
    when(orientacao){
        "E"-> {
            coordenadasCanto[0] = estaValida(tabuleiro, Pair(primeiraCasa.first - 1, primeiraCasa.second - 1))
            coordenadasCanto[1] = estaValida(tabuleiro, Pair(ultimaCasa.first - 1, ultimaCasa.second + 1))
            coordenadasCanto[2] = estaValida(tabuleiro, Pair(primeiraCasa.first + 1, primeiraCasa.second - 1))
            coordenadasCanto[3] = estaValida(tabuleiro, Pair(ultimaCasa.first + 1, ultimaCasa.second + 1))
            coordenadaExtremos[0] = estaValida(tabuleiro, Pair(primeiraCasa.first, primeiraCasa.second - 1))
            coordenadaExtremos[1] = estaValida(tabuleiro, Pair(ultimaCasa.first, ultimaCasa.second + 1)) }
        "O"->{
            coordenadasCanto[0]=estaValida(tabuleiro,Pair(ultimaCasa.first-1,ultimaCasa.second-1))
            coordenadasCanto[1]=estaValida(tabuleiro,Pair(primeiraCasa.first-1,primeiraCasa.second+1))
            coordenadasCanto[2]=estaValida(tabuleiro,Pair(ultimaCasa.first+1,ultimaCasa.second-1))
            coordenadasCanto[3]=estaValida(tabuleiro,Pair(primeiraCasa.first+1,primeiraCasa.second+1))
            coordenadaExtremos[0]=estaValida(tabuleiro,Pair(ultimaCasa.first,ultimaCasa.second-1))
            coordenadaExtremos[1]=estaValida(tabuleiro,Pair(primeiraCasa.first,primeiraCasa.second+1)) }
        "N"->{
            coordenadasCanto[0]=estaValida(tabuleiro,Pair(ultimaCasa.first-1,ultimaCasa.second-1))
            coordenadasCanto[1]=estaValida(tabuleiro,Pair(ultimaCasa.first-1,ultimaCasa.second+1))
            coordenadasCanto[2]=estaValida(tabuleiro,Pair(primeiraCasa.first+1,primeiraCasa.second-1))
            coordenadasCanto[3]=estaValida(tabuleiro,Pair(primeiraCasa.first+1,primeiraCasa.second+1))
            coordenadaExtremos[0]=estaValida(tabuleiro,Pair(ultimaCasa.first-1,ultimaCasa.second))
            coordenadaExtremos[1]=estaValida(tabuleiro,Pair(primeiraCasa.first+1,primeiraCasa.second)) }
        "S"->{
            coordenadasCanto[0]=estaValida(tabuleiro,Pair(primeiraCasa.first-1,primeiraCasa.second-1))
            coordenadasCanto[1]=estaValida(tabuleiro,Pair(primeiraCasa.first-1,primeiraCasa.second+1))
            coordenadasCanto[2]=estaValida(tabuleiro,Pair(ultimaCasa.first+1,ultimaCasa.second-1))
            coordenadasCanto[3]=estaValida(tabuleiro,Pair(ultimaCasa.first+1,ultimaCasa.second+1))
            coordenadaExtremos[0]=estaValida(tabuleiro,Pair(primeiraCasa.first-1,primeiraCasa.second))
            coordenadaExtremos[1]=estaValida(tabuleiro,Pair(ultimaCasa.first+1,ultimaCasa.second)) }
    }
    val coordenadaFinal: Array<Pair<Int, Int>> = juntarCoordenadas(juntarCoordenadas(coordenadasCanto,coordenadasResto),coordenadaExtremos)
    return  limparCoordenadasVazias(coordenadaFinal)
}

fun estaLivre(tabuleiro: Array<Array<Char?>>, coordenadas: Array<Pair<Int, Int>>): Boolean {
    for ((l, c) in coordenadas) {

        if (!coordenadaContida(tabuleiro,l,c)) {
            return false
        }
    }
    for ((l, c) in coordenadas) {
        if (tabuleiro[l-1][c-1] != null && tabuleiro[l-1][c-1]=='1') {
            //e se a condição for difere
            //acessa ao tabuleiro, então tem que ser -1
            //se não for null quer dizer que não está livre
            return false
        }
    }
    return true
}

fun insereNavioSimples(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, dimensao: Int): Boolean {
    return insereNavio(tabuleiro,linha,coluna,"E",dimensao)
}

fun insereNavio(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int, orientacao: String, dimensao: Int): Boolean {
    val coordenadasNavio=gerarCoordenadasNavio(tabuleiro,linha,coluna,orientacao,dimensao)
    val coordenadasFronteira=gerarCoordenadasFronteira(tabuleiro,linha, coluna, orientacao, dimensao)
    //verificar .isEmpty quer dizer que o size desse array é 0
    //exemplo, caso não consiga o gerarCoordenadasNavio, ele retorna um ,isEmpty
    if (!coordenadaContida(tabuleiro,linha,coluna) || coordenadasNavio.isEmpty() ){
        return false
    }
    val coordenadaFinal=juntarCoordenadas(coordenadasNavio,coordenadasFronteira)
    if (estaLivre(tabuleiro,coordenadaFinal)){
        for (coordenada in coordenadasNavio){
            tabuleiro[coordenada.first-1][coordenada.second-1]=dimensao.digitToChar()
            //nas posicoes, os nulls vao ser substituidos pelo numero da dimensao
        }
        return true
    }
    return false
}

fun preencheTabuleiroComputador(tabuleiro: Array<Array<Char?>>, configuracaoDoJogo: Array<Int>) {
    val tabuleiroTamanho = tabuleiro.size

    for (i in 0 until configuracaoDoJogo.size) {
        var dimensao: Int
        var linha: Int
        var coluna: Int
        var orientacao: String

        dimensao = (if (configuracaoDoJogo[i] != 0) i + 1 else 0)
        for (coordenada in 0 until configuracaoDoJogo[i]) {
            do {
                linha = (1..tabuleiroTamanho).random()
                coluna = (1..tabuleiroTamanho).random()
                orientacao = arrayOf("N", "S", "E", "O").random()
            } while (!insereNavio(tabuleiro, linha, coluna, orientacao, dimensao) )
        }
    }
}

fun linhas (tabuleiro: Array<Array<Char?>>, linha:Int):Array<Pair<Int,Int>>{
    val arrayFinal=Array<Pair<Int,Int>>(tabuleiro.size){ Pair(0,0) }
    for (i in 0 until tabuleiro.size){
        arrayFinal[i]=Pair(linha,i+1)
    }
    return arrayFinal
}

fun colunas(tabuleiro: Array<Array<Char?>>, coluna:Int):Array<Pair<Int,Int>>{
    val arrayFinal=Array<Pair<Int,Int>>(tabuleiro.size){ Pair(0,0) }
    for (i in 0 until tabuleiro.size){
        arrayFinal[i]=Pair(i+1,coluna)
    }
    return arrayFinal
}

fun navioCompleto(tabuleiro: Array<Array<Char?>>, linha: Int, coluna: Int): Boolean {
    val linhas=linhas(tabuleiro,linha)
    val colunas=colunas(tabuleiro,coluna)
    var coordenadasNavio:Array<Pair<Int,Int>>
    val dimensao= tabuleiro[linha-1][coluna-1].toString().toIntOrNull() ?: return false

    if ( dimensao == 1 ){
        return true
    }


    for (coordenada in linhas ){
        coordenadasNavio=gerarCoordenadasNavio(tabuleiro,coordenada.first,coordenada.second,"E", dimensao)
        var count=0

        for (coordenadaNavio in coordenadasNavio){
            if (tabuleiro[coordenadaNavio.first-1][coordenadaNavio.second-1] == dimensao.digitToChar()){
                count++
            }
        }
        //com este par verificamos se este é o navio que foi gerado na linha 71
        if (count==dimensao && Pair(linha,coluna) in coordenadasNavio){
            return true
        }
    }
    for (coordenada in colunas ){
        //usei o mais para concatenar os dois arrays
        coordenadasNavio=gerarCoordenadasNavio(tabuleiro,coordenada.first,coordenada.second,"S", dimensao)
        var count=0

        for (coordenadaNavio in coordenadasNavio){
            if (tabuleiro[coordenadaNavio.first-1][coordenadaNavio.second-1] == dimensao.digitToChar()){
                count++
            }
        }
        //com este par verificamos se este é o navio que foi gerado na linha 71
        if (count==dimensao && Pair(linha,coluna) in coordenadasNavio){
            return true
        }
    }

    return false
}

fun obtemMapa(tabuleiroRealOuPalpites: Array<Array<Char?>>, veracidade: Boolean): Array<String>{
    val tabuleiroTamanho = tabuleiroRealOuPalpites.size
    val linhas = tabuleiroTamanho
    val colunas = tabuleiroTamanho
    val mapa : Array<String> = Array(linhas+1) { "" }

    for (l in 0 until linhas) {
        var espaco = ""
        for (c in 0 until colunas) {
            val entreColunas = when {
                tabuleiroRealOuPalpites[l][c] == null -> if (veracidade) '~' else '?'
                veracidade -> tabuleiroRealOuPalpites[l][c]
                (tabuleiroRealOuPalpites[l][c] == 'x') -> tabuleiroRealOuPalpites[l][c]
                else -> {
                    val navioCompleto = navioCompleto(tabuleiroRealOuPalpites,l+1, c+1)
                    if (navioCompleto) {
                        tabuleiroRealOuPalpites[l][c]
                    } else {
                        when (tabuleiroRealOuPalpites[l][c]) {
                            '2' -> "\u2082"
                            '3' -> "\u2083"
                            '4' -> "\u2084"
                            'X'->'X'
                            else -> tabuleiroRealOuPalpites[l][c]
                        }
                    }
                }
            }
            espaco += "| $entreColunas "
        }
        if (l%2==0){
            espaco += "| 1"
            mapa[l+1] = espaco
        }else{
            espaco += "| 2"
            mapa[l+1] = espaco
        }
    }
    mapa[0] = "| ${criaLegendaHorizontal(colunas)} |"
    return mapa
}

fun lancarTiro(tabuleiroRealComputador: Array<Array<Char?>>, tabuleiroPalpitesHumano: Array<Array<Char?>>, coordenadasTiro: Pair<Int, Int>): String {
    val linha = coordenadasTiro.first - 1
    val coluna = coordenadasTiro.second - 1

    if(linha==0 && coluna==0 || linha==0 && coluna==tabuleiroRealComputador.size-1){
        tabuleiroPalpitesHumano[linha][coluna]= 'X'
        return "Agua."
    }
    val valor = tabuleiroRealComputador[linha][coluna]
    val navio = when (valor) {
        '1' -> "submarino."
        '2' -> "contra-torpedeiro."
        '3' -> "navio-tanque."
        '4' -> "porta-aviões."
        else -> "Agua."
    }

    if (navio == "Agua.") {
        tabuleiroPalpitesHumano[linha][coluna] = 'X'
        return navio
    } else {
        tabuleiroPalpitesHumano[linha][coluna] = valor
    }
    return "Tiro num $navio"
}

fun geraTiroComputador(tabuleiroPalpitesComputador: Array<Array<Char?>>): Pair<Int, Int> {
    val tamanhoTabuleiro=tabuleiroPalpitesComputador.size
    var linha: Int
    var coluna: Int

    do {
        linha=(0 until tamanhoTabuleiro).random()
        coluna=(0 until tamanhoTabuleiro).random()
    }while (tabuleiroPalpitesComputador[linha][coluna] !=null)

    return Pair(linha+1, coluna+1)
}

fun contarNaviosDeDimensao(tabuleiro: Array<Array<Char?>>, dimensao: Int): Int {
    var countNavios = 0
    var linha = 0
    var coluna = 0
    var dimensao1 = 0
//para percorrer as linhas do tabulerio
    while (linha < tabuleiro.size) {
        //Obtém o valor da célula atual no tabuleiro, converte para uma String, e depois para Int (ou null se não for possível).
        val celula = tabuleiro[linha][coluna]?.toString()?.toIntOrNull()
        //Verifica se o valor da célula corresponde à dimensão desejada do navio.
        if (celula == dimensao) {
            dimensao1++
            if (dimensao == 1){
                countNavios++
            }else if (dimensao1 == dimensao){
                countNavios++
            }
        }
        coluna++
        if (coluna == tabuleiro[linha].size) {
            //if (coluna == tabuleiro[linha].size):
            //Esta condição verifica se coluna atingiu o tamanho da linha atual (tabuleiro[linha].size).
            // Se isso acontecer, significa que alcançamos o final da linha.
            coluna = 0
            //Se coluna atingiu o final da linha, ela é resetada para 0.
            // Isso significa que, em vez de continuar na próxima coluna da linha atual,
            // vamos para a primeira coluna da próxima linha.
            linha++
        //Além de resetar a coluna para 0, incrementamos a variável linha.
        // Isso move o processo para a próxima linha do tabuleiro.
        }
    }
    return countNavios
}

fun venceu(tabuleiro: Array<Array<Char?>>): Boolean {
    val tamanhoTabuleiro = tabuleiro.size
    val navios = calculaNumNavios(tamanhoTabuleiro, tamanhoTabuleiro)
    for (i in 0 until navios.size) {
        if (contarNaviosDeDimensao(tabuleiro, i + 1) != navios[i]) {
            return false
        }
    }
    return true
}

fun lerJogo(nomeArquivo: String, tipoTabuleiro: Int): Array<Array<Char?>> {
    return emptyArray()
}

fun gravarJogo(nomeDoFicheiro: String, tabuleiroRealHumano: Array<Array<Char?>>,
               tabuleiroPalpitesHumano: Array<Array<Char?>>, tabuleiroRealComputador: Array<Array<Char?>>,
               tabuleiroPalpitesComputador: Array<Array<Char?>>) {
}

fun menuPrincipal(): Int {
    println()
    println("> > Batalha Naval < <")
    println()
    println("1 - Definir Tabuleiro e Navios")
    println("2 - Jogar")
    println("3 - Gravar")
    println("4 - Ler")
    println("0 - Sair")
    println()
    var escolha = readln().toIntOrNull()
    while (escolha != 0) {
        if (escolha == -1) {
            return MENU_PRINCIPAL
        }
        if (escolha == null) {
            do {
                println("!!! Opcao invalida, tente novamente")
                escolha = readln().toIntOrNull()
            } while (escolha == null)
        }
        when (escolha) {
            1->return MENU_DEFINIR_TABULEIRO
            2->return MENU_JOGAR
            3->return MENU_GRAVAR_FICHEIRO
            4->return MENU_LER_FICHEIRO
            else->{
                if (escolha!in 0..4){
                    do {
                        println("!!! Opcao invalida, tente novamente")
                        escolha = readln().toIntOrNull()
                    } while (escolha!in 0..4)
                }
            }
        }
    }
    return SAIR
}

fun linhasValidas(numLinhas: Int):Boolean{
    if (numLinhas == 4 || numLinhas == 5 || numLinhas == 7 || numLinhas == 8 || numLinhas == 10){
        return true
    }else{
        return false
    }
}
fun colunasValidas(numColunas: Int):Boolean{
    if (numColunas == 4 || numColunas == 5 || numColunas == 7 || numColunas == 8 || numColunas == 10){
        return true
    }else{
        return false
    }
}

fun tiposDeTabuleiros(dimensao: Int) {
    tabuleiroHumano = criaTabuleiroVazio(dimensao, dimensao)
    tabuleiroPalpitesDoHumano = criaTabuleiroVazio(dimensao, dimensao)
    tabuleiroComputador = criaTabuleiroVazio(dimensao, dimensao)
    tabuleiroPalpitesDoComputador = criaTabuleiroVazio(dimensao, dimensao)
}
fun tabuleiro(tabuleiroHumano: Array<Array<Char?>>, veracidade: Boolean){
    for (i in obtemMapa(tabuleiroHumano,veracidade)){
        println(i)
    }
}

fun menuDefinirTabuleiro(): Int {
    print("\n")
    println("> > Batalha Naval < <")
    print("\n")
    print("Defina o tamanho do tabuleiro:\n")
    print("Quantas linhas?\n")
    var numLinhas = readLine()?.toIntOrNull() ?: 0
    if (numLinhas == -1) {
        return MENU_PRINCIPAL
    }

    print("Quantas colunas?\n")
    var numColunas = readLine()?.toIntOrNull() ?: 0
    if (numColunas == -1) {
        return MENU_PRINCIPAL
    }

    while (!tamanhoTabuleiroValido(numLinhas, numColunas)) {
        println("Opção inválida, tente novamente")

        print("Quantas linhas?\n")
        numLinhas = readLine()?.toIntOrNull() ?: 0
        if (numLinhas == -1) {
            return MENU_PRINCIPAL
        }

        print("Quantas colunas?\n")
        numColunas = readLine()?.toIntOrNull() ?: 0
        if (numColunas == -1) {
            return MENU_PRINCIPAL
        }
    }

    if (tamanhoTabuleiroValido(numLinhas, numColunas)) {
        tiposDeTabuleiros(numLinhas)
        tabuleiro(tabuleiroHumano, true)
    } else {
        println("!!! Tamanho do tabuleiro inválido, tente novamente")
    }
    var count = 0
    while (count <= 1) {
        println("Insira as coordenadas de um submarino:")
        var coordenadas: String
        do {
            println("Coordenadas? (ex: 6,G)")
            coordenadas = readLine().toString()

            if (coordenadas == "-1") {
                return MENU_PRINCIPAL
            }

            val coordenadasValidas = processaCoordenadas(coordenadas, numLinhas, numColunas)

            if (coordenadasValidas != null) {
                val (linha, coluna) = coordenadasValidas
                processaCoordenadas(coordenadas, numLinhas, numColunas)

                tabuleiroHumano[linha - 1][coluna - 1] = '1'// Atualizando o tabuleiro com as coordenadas do submarino
                tabuleiro(tabuleiroHumano, true)

            } else {
                println("!!! Coordenadas inválidas, tente novamente")
            }
        } while (coordenadas != "-1" && processaCoordenadas(coordenadas, numLinhas, numColunas) == null)
        count++
    }

    val confirguracaoDoJogo: Array<Int> = calculaNumNavios(numLinhas,numColunas)
    preencheTabuleiroComputador(tabuleiroComputador,confirguracaoDoJogo)
    println("Pretende ver o mapa gerado para o Computador? (S/N)")
    val opcao = readln().toString()
    if (opcao == "S") {
        tabuleiro(tabuleiroComputador,true)
    }
    return MENU_PRINCIPAL
}



fun mensagem(jogador: String, alvoAtingido: String,
             tabuleiroPalpites: Array<Array<Char?>>, coordenadas: Pair<Int, Int>) {
    print(">>> ${jogador} >>>${alvoAtingido}")
    println(if (navioCompleto(tabuleiroPalpites, coordenadas.first, coordenadas.second)) " Navio ao fundo!" else "")
}

fun menuJogar(): Int {
    if (tabuleiroHumano.isEmpty() || tabuleiroComputador.isEmpty()) {
        println("!!! Tem que primeiro definir o tabuleiro do jogo, tente novamente")
        return MENU_PRINCIPAL
    }

    while (true){
        var coordenadasProcessadas: Pair<Int, Int>? = null
        var acertouAlvo = ""
        var computadorAcertouAlvo: Pair<Int, Int>
        tabuleiro(tabuleiroPalpitesDoHumano, false)
        println("Indique a posição que pretende atingir")
        var coordenadas: String
        val dimensao=tabuleiroHumano.size
        var coordenadasValidas=false
        do {
            println("Coordenadas? (ex: 6,G)")
            coordenadas = readLine().toString()
            coordenadasValidas = coordenadaContida(tabuleiroComputador ,dimensao,dimensao)
            if (coordenadas == "-1") {
                return MENU_PRINCIPAL
            }
            if ((coordenadasValidas)) {
                coordenadasProcessadas = processaCoordenadas(coordenadas, dimensao, dimensao)
            } else {
                println("!!! Coordenadas invalidas, tente novamente")
            }
            coordenadasValidas = coordenadaContida(tabuleiroComputador, dimensao, dimensao)
        }while (!coordenadasValidas)
        acertouAlvo=lancarTiro(tabuleiroComputador,tabuleiroPalpitesDoHumano,coordenadasProcessadas!!)
        mensagem("HUMANO", acertouAlvo, tabuleiroPalpitesDoHumano, coordenadasProcessadas)
        if (venceu(tabuleiroPalpitesDoHumano)) {
            println("PARABENS! Venceu o jogo!")
            println("Prima enter para voltar ao menu principal")
            readln()
            return MENU_PRINCIPAL
        }
        computadorAcertouAlvo = geraTiroComputador(tabuleiroPalpitesDoComputador)
        println("Computador lancou tiro para a posicao (${computadorAcertouAlvo.first}, ${computadorAcertouAlvo.second})")
        acertouAlvo = lancarTiro(tabuleiroHumano, tabuleiroPalpitesDoComputador, computadorAcertouAlvo)
        mensagem("COMPUTADOR", acertouAlvo, tabuleiroPalpitesDoHumano, coordenadasProcessadas)
        if (venceu(tabuleiroPalpitesDoComputador)) {
            println("PARABENS! Venceu o jogo")
            println("Prima enter para voltar ao menu principal")
            readln()
            return MENU_PRINCIPAL
        }
        println("Prima enter para continuar")
        readln()
    }
}

fun menuLerFicheiro(): Int {
    return 100
}

fun menuGravarFicheiro(): Int {
    return MENU_PRINCIPAL
}

fun main() {
    var menuActual = MENU_PRINCIPAL
    while (true) {
        menuActual = when (menuActual) {
            MENU_PRINCIPAL -> menuPrincipal()
            MENU_DEFINIR_TABULEIRO -> menuDefinirTabuleiro()
            MENU_JOGAR -> menuJogar()
            MENU_LER_FICHEIRO -> menuLerFicheiro()
            MENU_GRAVAR_FICHEIRO -> menuGravarFicheiro()
            SAIR -> return
            else -> return
        }
    }
}

